import React, { useEffect, useRef, useState } from 'react';
import { useGameLoop } from '../hooks/useGameLoop';
import { Player } from '../game/entities/Player';
import { Map } from '../game/map/Map';
import { Camera } from '../game/Camera';

const Game: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [player] = useState(new Player(400, 300, 'Player'));
  const [map] = useState(new Map());
  const [camera] = useState(new Camera());

  useGameLoop((deltaTime) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Update player and camera
    player.update(deltaTime);
    camera.follow(player.getBounds().x, player.getBounds().y);
    const cameraPos = camera.getPosition();

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Render map and player with camera offset
    map.render(ctx, cameraPos);
    player.render(ctx);
  });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      player.handleInput(e.key, true);
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      player.handleInput(e.key, false);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [player]);

  return (
    <canvas
      ref={canvasRef}
      width={800}
      height={600}
      className="game-canvas"
    />
  );
};

export default Game;