import React from 'react';

const Inventory: React.FC = () => {
  return (
    <div className="inventory">
      <h2>Inventory</h2>
      <div className="inventory-grid">
        {Array(16).fill(null).map((_, i) => (
          <div key={i} className="inventory-slot" />
        ))}
      </div>
      <div className="player-stats">
        <p>Gold: 0</p>
      </div>
    </div>
  );
};

export default Inventory;