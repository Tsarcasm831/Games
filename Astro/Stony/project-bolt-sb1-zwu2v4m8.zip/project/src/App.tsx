import React from 'react';
import Game from './components/Game';
import Inventory from './components/Inventory';
import './styles/game.css';

function App() {
  return (
    <div className="game-container">
      <Game />
      <div className="ui-container">
        <Inventory />
      </div>
    </div>
  );
}

export default App;