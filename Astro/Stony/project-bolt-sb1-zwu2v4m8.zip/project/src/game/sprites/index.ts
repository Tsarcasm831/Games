// Sprite URLs - using placeholder pixel art style images from a reliable source
export const SPRITES = {
  TERRAIN: {
    WATER: 'https://opengameart.org/sites/default/files/water_tile_1.png',
    GRASS: 'https://opengameart.org/sites/default/files/grass_tile_1.png',
    SAND: 'https://opengameart.org/sites/default/files/sand_tile_1.png',
    TREE: 'https://opengameart.org/sites/default/files/tree_1.png'
  },
  PLAYER: {
    IDLE: 'https://opengameart.org/sites/default/files/hero_1.png',
    WALK: 'https://opengameart.org/sites/default/files/hero_walk.png'
  },
  ITEMS: {
    POTION: 'https://opengameart.org/sites/default/files/potion_1.png',
    SWORD: 'https://opengameart.org/sites/default/files/sword_1.png',
    SHIELD: 'https://opengameart.org/sites/default/files/shield_1.png'
  }
};