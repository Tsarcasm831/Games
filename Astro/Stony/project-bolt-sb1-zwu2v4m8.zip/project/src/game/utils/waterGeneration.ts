interface Point {
  x: number;
  y: number;
}

function floodFill(map: number[][], x: number, y: number, targetValue: number): number {
  if (x < 0 || x >= map[0].length || y < 0 || y >= map.length) return 0;
  if (map[y][x] !== targetValue) return 0;

  let size = 1;
  map[y][x] = -1; // Mark as visited

  // Check all adjacent cells
  size += floodFill(map, x + 1, y, targetValue);
  size += floodFill(map, x - 1, y, targetValue);
  size += floodFill(map, x, y + 1, targetValue);
  size += floodFill(map, x, y - 1, targetValue);

  return size;
}

export function connectWaterBodies(noise: number[][]): number[][] {
  const waterThreshold = 0.3;
  const minLakeSize = 10;
  const map = noise.map(row => row.map(value => value < waterThreshold ? 0 : 1));
  
  // Find water bodies and their sizes
  const waterBodies: Point[] = [];
  const mapCopy = map.map(row => [...row]);
  
  for (let y = 0; y < map.length; y++) {
    for (let x = 0; x < map[0].length; x++) {
      if (mapCopy[y][x] === 0) {
        const size = floodFill(mapCopy, x, y, 0);
        if (size < minLakeSize) {
          waterBodies.push({ x, y });
        }
      }
    }
  }

  // Connect isolated water bodies to nearest larger water body
  waterBodies.forEach(point => {
    let nearestWater: Point | null = null;
    let minDistance = Infinity;

    // Find nearest large water body
    for (let y = 0; y < map.length; y++) {
      for (let x = 0; x < map[0].length; x++) {
        if (map[y][x] === 0) {
          const dist = Math.sqrt(Math.pow(x - point.x, 2) + Math.pow(y - point.y, 2));
          if (dist < minDistance && dist > 2) {
            minDistance = dist;
            nearestWater = { x, y };
          }
        }
      }
    }

    // Create water path to connect
    if (nearestWater) {
      const dx = Math.sign(nearestWater.x - point.x);
      const dy = Math.sign(nearestWater.y - point.y);
      let x = point.x;
      let y = point.y;

      while (x !== nearestWater.x || y !== nearestWater.y) {
        map[y][x] = 0;
        if (x !== nearestWater.x) x += dx;
        if (y !== nearestWater.y) y += dy;
      }
    }
  });

  return map;
}