export function generateNoise(width: number, height: number): number[][] {
  const noise: number[][] = [];
  
  // Initialize with random values
  for (let y = 0; y < height; y++) {
    noise[y] = [];
    for (let x = 0; x < width; x++) {
      noise[y][x] = Math.random();
    }
  }
  
  // Smooth the noise
  const smoothedNoise: number[][] = [];
  for (let y = 0; y < height; y++) {
    smoothedNoise[y] = [];
    for (let x = 0; x < width; x++) {
      let sum = 0;
      let count = 0;
      
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const ny = y + dy;
          const nx = x + dx;
          
          if (ny >= 0 && ny < height && nx >= 0 && nx < width) {
            sum += noise[ny][nx];
            count++;
          }
        }
      }
      
      smoothedNoise[y][x] = sum / count;
    }
  }
  
  return smoothedNoise;
}