export class Player {
  x: number;
  y: number;
  speed: number;
  movement: { up: boolean; down: boolean; left: boolean; right: boolean };

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.speed = 200;
    this.movement = { up: false, down: false, left: false, right: false };
  }

  handleInput(key: string, isDown: boolean) {
    switch (key) {
      case 'ArrowUp':
      case 'w':
        this.movement.up = isDown;
        break;
      case 'ArrowDown':
      case 's':
        this.movement.down = isDown;
        break;
      case 'ArrowLeft':
      case 'a':
        this.movement.left = isDown;
        break;
      case 'ArrowRight':
      case 'd':
        this.movement.right = isDown;
        break;
    }
  }

  update(deltaTime: number) {
    if (this.movement.up) this.y -= this.speed * deltaTime;
    if (this.movement.down) this.y += this.speed * deltaTime;
    if (this.movement.left) this.x -= this.speed * deltaTime;
    if (this.movement.right) this.x += this.speed * deltaTime;
  }

  render(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(this.x - 15, this.y - 15, 30, 30);
  }
}