export interface Tile {
  type: 'water' | 'grass' | 'sand' | 'tree';
  walkable: boolean;
  sprite: string;
}