import { Tile } from './Tile';
import { generateNoise } from '../utils/noise';
import { connectWaterBodies } from '../utils/waterGeneration';

export class MapGenerator {
  static generate(width: number = 50, height: number = 38): Tile[][] {
    const tiles: Tile[][] = [];
    const noise = generateNoise(width, height);
    const waterMap = connectWaterBodies(noise);
    
    for (let y = 0; y < height; y++) {
      tiles[y] = [];
      for (let x = 0; x < width; x++) {
        const value = noise[y][x];
        
        if (waterMap[y][x] === 0) {
          tiles[y][x] = {
            type: 'water',
            walkable: false,
            sprite: 'water'
          };
        } else if (value < 0.6) {
          tiles[y][x] = {
            type: 'grass',
            walkable: true,
            sprite: 'grass'
          };
        } else if (value < 0.8) {
          tiles[y][x] = {
            type: 'sand',
            walkable: true,
            sprite: 'sand'
          };
        } else {
          tiles[y][x] = {
            type: 'tree',
            walkable: false,
            sprite: 'tree'
          };
        }
      }
    }
    
    return tiles;
  }
}