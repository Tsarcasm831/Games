export class MapMemory {
  private visited: Set<string>;

  constructor() {
    this.visited = new Set();
  }

  markAsVisited(x: number, y: number) {
    this.visited.add(`${x},${y}`);
  }

  hasVisited(x: number, y: number): boolean {
    return this.visited.has(`${x},${y}`);
  }
}