import { Tile } from './Tile';
import { SPRITES } from '../sprites';
import { AssetLoader } from '../AssetLoader';
import { MapGenerator } from './MapGenerator';
import { MapMemory } from './MapMemory';

export class Map {
  private tiles: Tile[][];
  private tileSize: number;
  private sprites: Record<string, HTMLImageElement | null> = {};
  private memory: MapMemory;
  private fallbackColors = {
    water: '#4444ff',
    grass: '#44ff44',
    sand: '#ffff44',
    tree: '#228822'
  };

  constructor() {
    this.tileSize = 48;
    this.memory = new MapMemory();
    this.tiles = MapGenerator.generate();
    this.loadSprites().catch(console.error);
  }

  private async loadSprites() {
    const loader = AssetLoader.getInstance();
    try {
      this.sprites.water = await loader.loadImage(SPRITES.TERRAIN.WATER);
      this.sprites.grass = await loader.loadImage(SPRITES.TERRAIN.GRASS);
      this.sprites.sand = await loader.loadImage(SPRITES.TERRAIN.SAND);
      this.sprites.tree = await loader.loadImage(SPRITES.TERRAIN.TREE);
    } catch (error) {
      console.warn('Failed to load some sprites, using fallback colors:', error);
      this.sprites = {
        water: null,
        grass: null,
        sand: null,
        tree: null
      };
    }
  }

  isCurrentlyVisible(x: number, y: number, startX: number, startY: number, endX: number, endY: number): boolean {
    return x >= startX && x < endX && y >= startY && y < endY;
  }

  render(ctx: CanvasRenderingContext2D, camera: { x: number; y: number }) {
    const startX = Math.floor(camera.x / this.tileSize);
    const startY = Math.floor(camera.y / this.tileSize);
    const endX = startX + Math.ceil(ctx.canvas.width / this.tileSize) + 1;
    const endY = startY + Math.ceil(ctx.canvas.height / this.tileSize) + 1;

    // Update visible area in memory
    for (let y = startY; y < endY; y++) {
      for (let x = startX; x < endX; x++) {
        if (y >= 0 && y < this.tiles.length && x >= 0 && x < this.tiles[0].length) {
          this.memory.markAsVisited(x, y);
        }
      }
    }

    // Render the map with fog of war
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    for (let y = startY; y < endY; y++) {
      for (let x = startX; x < endX; x++) {
        if (y >= 0 && y < this.tiles.length && x >= 0 && x < this.tiles[0].length) {
          if (this.memory.hasVisited(x, y)) {
            const tile = this.tiles[y][x];
            const sprite = this.sprites[tile.type];
            const screenX = x * this.tileSize - camera.x;
            const screenY = y * this.tileSize - camera.y;
            
            ctx.globalAlpha = this.isCurrentlyVisible(x, y, startX, startY, endX, endY) ? 1 : 0.5;
            
            if (sprite) {
              ctx.drawImage(sprite, screenX, screenY, this.tileSize, this.tileSize);
            } else {
              ctx.fillStyle = this.fallbackColors[tile.type];
              ctx.fillRect(screenX, screenY, this.tileSize, this.tileSize);
            }
          }
        }
      }
    }
    ctx.globalAlpha = 1;
  }

  isTileWalkable(x: number, y: number): boolean {
    const tileX = Math.floor(x / this.tileSize);
    const tileY = Math.floor(y / this.tileSize);
    
    if (tileY >= 0 && tileY < this.tiles.length && tileX >= 0 && tileX < this.tiles[0].length) {
      return this.tiles[tileY][tileX].walkable;
    }
    return false;
  }
}