import { Item } from './Item';

export class Inventory {
  private slots: (Item | null)[];
  private gold: number;

  constructor(size: number) {
    this.slots = new Array(size).fill(null);
    this.gold = 0;
  }

  addItem(item: Item): boolean {
    if (item.stackable) {
      const existingSlot = this.slots.findIndex(
        slot => slot?.id === item.id && slot.quantity! < 99
      );
      if (existingSlot !== -1) {
        this.slots[existingSlot]!.quantity! += item.quantity || 1;
        return true;
      }
    }

    const emptySlot = this.slots.findIndex(slot => slot === null);
    if (emptySlot !== -1) {
      this.slots[emptySlot] = item;
      return true;
    }
    return false;
  }

  removeItem(slotIndex: number): Item | null {
    const item = this.slots[slotIndex];
    this.slots[slotIndex] = null;
    return item;
  }

  getItems() {
    return this.slots;
  }

  addGold(amount: number) {
    this.gold += amount;
  }

  getGold() {
    return this.gold;
  }
}