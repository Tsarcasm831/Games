export class Map {
  tiles: number[][];
  tileSize: number;

  constructor() {
    this.tileSize = 32;
    this.tiles = this.generateMap();
  }

  generateMap() {
    const mapWidth = 25;
    const mapHeight = 19;
    const tiles: number[][] = [];

    for (let y = 0; y < mapHeight; y++) {
      tiles[y] = [];
      for (let x = 0; x < mapWidth; x++) {
        // Simple terrain generation
        const rand = Math.random();
        if (rand < 0.3) tiles[y][x] = 0; // Water
        else if (rand < 0.6) tiles[y][x] = 1; // Grass
        else tiles[y][x] = 2; // Sand
      }
    }

    return tiles;
  }

  render(ctx: CanvasRenderingContext2D) {
    for (let y = 0; y < this.tiles.length; y++) {
      for (let x = 0; x < this.tiles[y].length; x++) {
        const tileType = this.tiles[y][x];
        
        switch (tileType) {
          case 0: // Water
            ctx.fillStyle = '#4444ff';
            break;
          case 1: // Grass
            ctx.fillStyle = '#44ff44';
            break;
          case 2: // Sand
            ctx.fillStyle = '#ffff44';
            break;
        }

        ctx.fillRect(
          x * this.tileSize,
          y * this.tileSize,
          this.tileSize,
          this.tileSize
        );
      }
    }
  }
}