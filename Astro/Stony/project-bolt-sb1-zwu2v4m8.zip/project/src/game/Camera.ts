export class Camera {
  x: number = 0;
  y: number = 0;
  private targetX: number = 0;
  private targetY: number = 0;
  private smoothing: number = 0.1;

  follow(x: number, y: number) {
    this.targetX = x - window.innerWidth / 2;
    this.targetY = y - window.innerHeight / 2;
    
    // Smooth camera movement
    this.x += (this.targetX - this.x) * this.smoothing;
    this.y += (this.targetY - this.y) * this.smoothing;
  }

  getPosition() {
    return { x: Math.floor(this.x), y: Math.floor(this.y) };
  }
}