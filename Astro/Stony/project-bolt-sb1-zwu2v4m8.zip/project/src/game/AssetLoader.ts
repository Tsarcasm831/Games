export class AssetLoader {
  private static instance: AssetLoader;
  private loadedAssets: Map<string, HTMLImageElement> = new Map();
  private loadingPromises: Map<string, Promise<HTMLImageElement>> = new Map();

  private constructor() {}

  static getInstance(): AssetLoader {
    if (!AssetLoader.instance) {
      AssetLoader.instance = new AssetLoader();
    }
    return AssetLoader.instance;
  }

  async loadImage(url: string): Promise<HTMLImageElement> {
    // Return cached image if available
    if (this.loadedAssets.has(url)) {
      return this.loadedAssets.get(url)!;
    }

    // Return existing promise if already loading
    if (this.loadingPromises.has(url)) {
      return this.loadingPromises.get(url)!;
    }

    const promise = new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      
      const timeoutId = setTimeout(() => {
        reject(new Error(`Timeout loading image: ${url}`));
      }, 5000);

      img.onload = () => {
        clearTimeout(timeoutId);
        this.loadedAssets.set(url, img);
        this.loadingPromises.delete(url);
        resolve(img);
      };

      img.onerror = () => {
        clearTimeout(timeoutId);
        this.loadingPromises.delete(url);
        reject(new Error(`Failed to load image: ${url}`));
      };

      img.src = url;
    });

    this.loadingPromises.set(url, promise);
    return promise;
  }

  getImage(url: string): HTMLImageElement | undefined {
    return this.loadedAssets.get(url);
  }
}