import { Entity } from './Entity';
import { SPRITES } from '../sprites';
import { AssetLoader } from '../AssetLoader';
import { Inventory } from '../inventory/Inventory';

export class Player extends Entity {
  private speed: number;
  private movement: { up: boolean; down: boolean; left: boolean; right: boolean };
  private sprite: HTMLImageElement | null = null;
  private inventory: Inventory;
  private username: string;

  constructor(x: number, y: number, username: string) {
    super(x, y, 48, 48);
    this.speed = 200;
    this.movement = { up: false, down: false, left: false, right: false };
    this.inventory = new Inventory(16);
    this.username = username;
    this.loadSprite().catch(console.error);
  }

  private async loadSprite() {
    try {
      this.sprite = await AssetLoader.getInstance().loadImage(SPRITES.PLAYER.IDLE);
    } catch (error) {
      console.warn('Failed to load player sprite:', error);
      this.sprite = null;
    }
  }

  handleInput(key: string, isDown: boolean) {
    switch (key.toLowerCase()) {
      case 'arrowup':
      case 'w':
        this.movement.up = isDown;
        break;
      case 'arrowdown':
      case 's':
        this.movement.down = isDown;
        break;
      case 'arrowleft':
      case 'a':
        this.movement.left = isDown;
        break;
      case 'arrowright':
      case 'd':
        this.movement.right = isDown;
        break;
    }
  }

  update(deltaTime: number) {
    // Calculate new position based on movement
    let newX = this.x;
    let newY = this.y;

    if (this.movement.up) newY -= this.speed * deltaTime;
    if (this.movement.down) newY += this.speed * deltaTime;
    if (this.movement.left) newX -= this.speed * deltaTime;
    if (this.movement.right) newX += this.speed * deltaTime;

    // Update position
    this.x = newX;
    this.y = newY;
  }

  render(ctx: CanvasRenderingContext2D) {
    if (this.sprite) {
      ctx.drawImage(
        this.sprite,
        this.x - this.width/2,
        this.y - this.height/2,
        this.width,
        this.height
      );
    } else {
      // Fallback rendering when sprite isn't available
      ctx.fillStyle = '#ff0000';
      ctx.fillRect(
        this.x - this.width/2,
        this.y - this.height/2,
        this.width,
        this.height
      );
    }

    // Draw username
    ctx.fillStyle = 'white';
    ctx.font = '14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(this.username, this.x, this.y - this.height/2 - 10);
  }

  getInventory() {
    return this.inventory;
  }
}